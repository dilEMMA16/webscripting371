<?php
include ('header.php');

$conn = new mysqli('rei.cs.ndsu.nodak.edu', 'emmschre_371s17', 'DAm8GEgXO6');

	// Check connection
	//if ($conn->connect_error) {
		//die("Connection failed: " . $conn->connect_error);
	//}
	//else{
		//echo "Connected successfully";
	//}
  mysqli_select_db($conn, "emmschre_371s17");

  //save the advisor ID in a variable
  $aID = $_COOKIE["advisorid"];
  $sID = $_COOKIE["sid"];
  $monday = "2017-05-08";
  $tuesday = "2017-05-09";
  $wednesday = "2017-05-10";
  $thursday = "2017-05-11";
  $friday = "2017-05-12";
  ?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Schedule</title>
	<link rel="stylesheet" type="text/css" href="style-sign.css">
    <link href='//fonts.googleapis.com/css?family=Bokor' rel='stylesheet'>
    <style>
        body {font-family: 'Bokor';}
        table {padding: 25px;}
		.thead {
			 text-align: center;
			 background-color: #5D6D7E;
			 color: white;
			 padding: 15px;}
		#buttonformat {
			display: inline block;
			background: #85929E;
			padding: 10px;
			text-align: center;
			border-radius: 5px;
			color: white;
			font-weight: bold;
			text-decoration: none;}
</style>
</head>
<body>
       <center>
        <h1>Change an Appointment</h1>
        Please choose which of your current appointments to change:
        <?php
        $badcount =0;
        print "<form method='POST' action='changeschedulenew.php'>";
        print "<table>";
        
        print "<tr>
               <td class = 'thead'>Monday</td>
               <td class = 'thead'>Tuesday</td>
               <td class = 'thead'>Wednesday</td>
               <td class = 'thead'>Thursday</td>
               <td class = 'thead'>Friday</td>
               </tr>";
        print "<tr>";
		//mon
		print "<td>";
			   $query1 = "SELECT Time FROM appointments WHERE Status = 1 AND AdvisorID ='".$aID."' AND StudentID = '".$sID."' AND Date='".$monday."';";
			   $result1 = $conn->query($query1);
			   $querygood = true;
							
                            $numappts = 0;
                                 for($c=0; $row=  mysqli_fetch_row($result1); $c++)
                                  {
                                       foreach($row as $key => $value)
                                       {
                                          $newValue1 = (string)$value."1";
                                          $numappts = $numappts + 1;
                                          print "<input required type='radio' name='timed' value='".$newValue1."'> $value <br>";
                                       }
                                       
                                  }
                                  
                               if ( $numappts == 0)
                                {
                                 print "<h4>No appts</h4>";
                                        $querygood = false;
                                        $badcount = $badcount + 1;
                                }   
							      
		print "</td>";
		//tues
		print "<td>";
			   $query2 = "SELECT Time FROM appointments WHERE Status = 1 AND AdvisorID ='".$aID."' AND StudentID = '".$sID."' AND Date='".$tuesday."';";
			   $result2 = $conn->query($query2);
			   $querygood = true;
							
                           $numappts = 0;
                                 for($c=0; $row=  mysqli_fetch_row($result2); $c++)
                                  {
                                       foreach($row as $key => $value)
                                       {
                                          $newValue2 = (string)$value."2";
                                          $numappts = $numappts + 1;
                                          print "<input required type='radio' name='timed' value='".$newValue2."'> $value <br>";
                                       }       
                                  }
                                  
                               if ( $numappts == 0)
                                {
                                 print "<h4>No appts</h4>";
                                        $querygood = false;
                                        $badcount = $badcount + 1;
                                }                      
                         
		print "</td>";
		//wed
		print "<td>";
			   $query3 = "SELECT Time FROM appointments WHERE Status = 1 AND AdvisorID ='".$aID."' AND StudentID = '".$sID."' AND Date='".$wednesday."';";
			   $result3 = $conn->query($query3);
			   $querygood = true;
							
                           $numappts = 0;
                                 for($c=0; $row=  mysqli_fetch_row($result3); $c++)
                                  {
                                       foreach($row as $key => $value)
                                       {
                                          $newValue3 = (string)$value."3";
                                          $numappts = $numappts + 1;
                                          print "<input required type='radio' name='timed' value='".$newValue3."'> $value <br>";
                                       }    
                                  }
                                  
                               if ( $numappts == 0)
                                {
                                 print "<h4>No appts</h4>";
                                        $querygood = false;
                                        $badcount = $badcount + 1;
                                }   
                                               
		print "</td>";
		//thurs
		print "<td>";
			   $query4 = "SELECT Time FROM appointments WHERE Status = 1 AND AdvisorID ='".$aID."' AND StudentID = '".$sID."' AND Date='".$thursday."';";
			   $result4 = $conn->query($query4);
			   $querygood = true;
							
                            $numappts = 0;
                                 for($c=0; $row=  mysqli_fetch_row($result4); $c++)
                                  {
                                       foreach($row as $key => $value)
                                       {
                                          $newValue4 = (string)$value."4";
                                          $numappts = $numappts + 1;
                                          print "<input required type='radio' name='timed' value='".$newValue4."'> $value <br>";
                                       }
                                       
                                  }
                                  
                               if ( $numappts == 0)
                                {
                                 print "<h4>No appts</h4>";
                                        $querygood = false;
                                        $badcount = $badcount + 1;
                                }   
                               
		print "</td>";
		//fri
		print "<td>";
			   $query5 = "SELECT Time FROM appointments WHERE Status = 1 AND AdvisorID ='".$aID."' AND StudentID = '".$sID."' AND Date='".$friday."';";
			   $result5 = $conn->query($query5);
			   $querygood = true;
							
                           $numappts = 0;
                                 for($c=0; $row=  mysqli_fetch_row($result5); $c++)
                                  {
                                       foreach($row as $key => $value)
                                       {
                                          $newValue5 = (string)$value."5";
                                          $numappts = $numappts + 1;
                                          print "<input required type='radio' name='timed' value='".$newValue5."'> $value <br>";
                                       }
                                       
                                  }
                                  
                               if ( $numappts == 0)
                                {
                                 print "<h4>No appts</h4>";
                                        $querygood = false;
                                        $badcount = $badcount + 1;
                                }   
                           
		print "</td>";
	
	print "</tr>";
	
		print "</table>"; 
        
        if ($badcount == 5)
        
        {
             print "<a  class= 'buttonlink' href= 'http://students.cs.ndsu.nodak.edu/~emmschre/finalwebscripting/schedule.php'>No Appointments? Schedule One</a>";      
        }
        
        else
        {
             print "<br><br><input type = 'submit' id = 'buttonformat' name = 'submit' value = 'Change Appt'><br><br>";
        }
       
        print "</form><br><br><br>";
        
        $conn->close(); ?>
            
</center> 
<br>  <br> 

</body>
</html>

<?php
include ('footer.php'); ?>