<?php
	// Create connection
	$conn = new mysqli('rei.cs.ndsu.nodak.edu', 'emmschre_371s17', 'DAm8GEgXO6');

	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}
	else{
		echo "Connected successfully";
	}
  
  mysqli_select_db($conn, "emmschre_371s17");
 
  $user = $_POST["user"];
  $pass = $_POST["pass"];
  
  setcookie("user", $user);
  
  $query = "SELECT * FROM students WHERE Username='".$user."' AND Password='".$pass."';";
  $result = $conn->query($query);
  
  if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_array()) {
        echo "<br><br>id: " . $row["StudentID"]. " - Name: " . $row["FirstName"]. " " . $row["LastName"]. "<br>";
        
        
        $sid = $row["StudentID"];
        setcookie("sid", $sid);
        
        $sfirstname = $row["FirstName"];
        setcookie("sfirstname", $sfirstname);
        
        $slastname = $row["LastName"];
        setcookie("slastname", $slastname);
        
        $susername = $row["Username"];
        setcookie("susername", $susername);
        
        $spassword = $row["Password"];
        setcookie("spassword", $spassword);
        
        $semail = $row["Email"];
        setcookie("semail", $semail);
        
        
        $advisorid = $row["AdvisorID"];
        setcookie("advisorid", $row["AdvisorID"]);
        
        
        $query1 = "SELECT * FROM advisors WHERE AdvisorID='".$advisorid."';";
        $result1 = $conn->query($query1);
        
        while($row1 = $result1->fetch_array())
        {
            $afirstname = $row1["FirstName"];
            setcookie("afirstname", $afirstname);
            
            $alastname = $row1["LastName"];
            setcookie("alastname", $alastname);
            
            $aoffice = $row1["Office"];
            setcookie("aoffice", $aoffice);
            
            $aemail = $row1["Email"];
            setcookie("aemail", $aemail);
        }
        
        
        header("location: welcome.php");
    }
   } else {
        header("location: redirect.php");
    }
    
  $conn->close();
  
 ?>