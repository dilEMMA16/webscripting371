<?php include ('header.php');
// Create connection
	$conn = new mysqli('rei.cs.ndsu.nodak.edu', 'emmschre_371s17', 'DAm8GEgXO6');

	// Check connection
	//if ($conn->connect_error) {
		//die("Connection failed: " . $conn->connect_error);
	//}
	//else{
		//echo "Connected successfully";
	//}
  
  mysqli_select_db($conn, "emmschre_371s17");

  //save the advisor ID in a variable
  $aID = $_COOKIE["advisorid"];
  $time = $_POST["time"];
  
  //set cookies if needed
  setcookie("apptday", $date);
   
  //gather needed information
  $sname = $_COOKIE["sfirstname"] . " " . $_COOKIE["slastname"];
  $sID = $_COOKIE["sid"];
  $aname = "Professor" . " " . $_COOKIE["afirstname"] . " " . $_COOKIE["alastname"];
  $date = $_COOKIE["apptday"];
  $office = $_COOKIE["aoffice"];
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Confirmation</title>
    <link href='//fonts.googleapis.com/css?family=Bokor' rel='stylesheet'>
    <style>
        body {font-family: 'Bokor';}
</style>
</head>
<body>
    <center><h1>Confirmation Page</h1>
    Thank you for scheduling an advisor appointment! 
    <br>
    <br>
	<h3>Appointment Information:</h3>
	Student Name: <?php echo $sname;?><br>
	Student ID: <?php echo $sID;?><br>
	Advisor Name: <?php echo $aname;?><br>
	Advisor ID: <?php echo $aID;?><br>
	Date: <?php echo $date;?><br>
	Time: <?php echo $time;?><br>
	Office: <?php echo $office;?><br>
    <br>
    <?php
	//set query to put appointment in data base = set status to 1, insert student id etc. use update!
	$query = "UPDATE appointments SET StudentID = '".$sID."', Status = '1' WHERE Date = '".$date."'
			  AND AdvisorID ='".$aID."' AND Time ='".$time."';"; 
	$result = $conn->query($query);

    $conn->close();       
?>
<br><br><br><br><br><br><br>
</center>
</body>
</html>
<?php
include ('footer.php');?>
