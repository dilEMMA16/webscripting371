<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Redirect</title>
    <link rel="stylesheet" type="text/css" href="style-sign.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lobster">
		<style>
			.lobster {
				    font-family: "Lobster", serif;
				}
		</style>
</head>
<body id="body-color">
    <div id="Sign-In">
    <h1 class="lobster">Unrecognized username and/or password</h1>
    <br><br>
    <?php
    echo ("Would you like to try again?
          <a href=\"login.html\"> <br> Click here to return to the log in page </a>
          ")
    ?>
    </div>
    
</body>
</html>