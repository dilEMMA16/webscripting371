<div id="footer">  
		<br>
        
		<h3 id="headandfoot"><center>
        <script>
            
            document.write("Created by Madelyn Leonard and Emma Schreifels");
            
        </script>
        </center></h3>
		</div>
	
</body>
</html>