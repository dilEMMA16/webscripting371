<?php include ('header.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
     <link rel="stylesheet" type="text/css" href="style-sign.css">
    <link href='//fonts.googleapis.com/css?family=Bokor' rel='stylesheet'>
    <style>
        body {
        font-family: 'Bokor';
        }
</style>
</head>
<body>
    <center><h1>Welcome <?php echo $_COOKIE["sfirstname"]?> <?php echo $_COOKIE["slastname"]?>!</h1>
    <h3>Your advisor's name is Professor <?php echo $_COOKIE["afirstname"]?> <?php echo $_COOKIE["alastname"]?>.</h3>
    
    <h3>What would you like to do? </h3><br>
    
        <a  class= "buttonlink" href= "http://students.cs.ndsu.nodak.edu/~emmschre/finalwebscripting/schedule.php">Schedule an Appointment</a>
        <a class= "buttonlink" href= "http://students.cs.ndsu.nodak.edu/~emmschre/finalwebscripting/change.php"">Change an Appointment</a>
        <a class= "buttonlink" href= "http://students.cs.ndsu.nodak.edu/~emmschre/finalwebscripting/delete.php">Delete an Appointment</a>
</center>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <h2></h2>
</body>
</html>
<?php include ('footer.php'); ?>
