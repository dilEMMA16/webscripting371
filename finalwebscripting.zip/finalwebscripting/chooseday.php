<?php include ('header.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Choose Day</title>
    <link rel="stylesheet" type="text/css" href="style-sign.css">
    <link href='//fonts.googleapis.com/css?family=Bokor' rel='stylesheet'>
    <style>
        body {font-family: 'Bokor';}
        table {padding: 25px;}
		.thead {
			 text-align: center;
			 background-color: #5D6D7E;
			 color: white;
			 padding: 15px;}
		#buttonformat{
			display: inline block;
			background: #85929E;
			padding: 10px;
			text-align: center;
			border-radius: 5px;
			color: white;
			font-weight: bold;
			text-decoration: none;}
    </style>
</head>
<body>
  <form method="POST" action="dayview.php">
    <center>
    <h1>Please choose a day of the week:</h1><br>
    <input required type="radio" name="day" value = "2017-05-08">Monday <br>
    <input type="radio" name="day" value = "2017-05-09">Tuesday <br>
    <input type="radio" name="day" value = "2017-05-10">Wednesday <br>
    <input type="radio" name="day" value = "2017-05-11">Thursday <br>
    <input type="radio" name="day" value = "2017-05-12">Friday <br><br>
    <input type="submit" id = "buttonformat" name = "submit" value="See Appointments">
    </center>
  </form>   
</body>
</html>
<?php include ('footer.php'); ?>