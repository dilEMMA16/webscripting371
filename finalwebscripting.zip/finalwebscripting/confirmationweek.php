<?php include ('header.php');
// Create connection
	$conn = new mysqli('rei.cs.ndsu.nodak.edu', 'emmschre_371s17', 'DAm8GEgXO6');

	// Check connection
	//if ($conn->connect_error) {
		//die("Connection failed: " . $conn->connect_error);
	//}
	//else{
		//echo "Connected successfully";
	//}
  
  mysqli_select_db($conn, "emmschre_371s17");

  //save the advisor ID in a variable
  $aID = $_COOKIE["advisorid"];
  $enteredChoice = $_POST["time"];
  $apptday; 
  
  $dayCode = substr($enteredChoice, 8);
  
		//figure out date from dayCode
		if ($dayCode == 1) { $apptday = "2017-05-08";}
		else if ($dayCode == 2) { $apptday = "2017-05-09";}
		else if ($dayCode == 3) { $apptday = "2017-05-10";}
		else if ($dayCode == 4) { $apptday = "2017-05-11";}
		else if ($dayCode == 5) { $apptday = "2017-05-12";}
		
  //get time = need to take off last digit of entered choice's value
  $time = substr ($enteredChoice, 0, -1);
  
  //gather needed information
  $sname = $_COOKIE["sfirstname"] . " " . $_COOKIE["slastname"];
  $sID = $_COOKIE["sid"];
  $aname = "Professor" . " " . $_COOKIE["afirstname"] . " " . $_COOKIE["alastname"];
  $date = $apptday;
  $office = $_COOKIE["aoffice"];
  
  $email = (string)$_COOKIE["semail"];
  
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Confirmation</title>
    <link href='//fonts.googleapis.com/css?family=Bokor' rel='stylesheet'>
    <style>
        body {
        font-family: 'Bokor';
        }
</style>
</head>
<body>
    <center><h1>Confirmation Page</h1>
    Thank you for scheduling an advisor appointment! 
    <br>
    <br>
	<h3>Appointment Information:</h3>
	Student Name: <?php echo $sname;?><br>
	Student ID: <?php echo $sID;?><br>
	Advisor Name: <?php echo $aname;?><br>
	Advisor ID: <?php echo $aID;?><br>
	Date: <?php echo $date;?><br>
	Time: <?php echo $time;?><br>
	Office: <?php echo $office;?><br>
    <br>
	
    <?php
	//send email
	// the message
	$msg = "Thank you for scheduling an advisor appointment!\r\n
			Student Name : " . $sname . "\r\nStudent ID: " . $sID .
			"\r\nAdvisor Name : " . $aname . "\r\nAdvisor ID: "
			. $aID . "\r\nDate: " . $date . "\r\nTime: " . $time . "\r\nOffice: " . $office . "\r\n";
	
	// use wordwrap() if lines are longer than 70 characters
	$msg = wordwrap($msg,70,"\r\n");
	
	
	//second try
	$headers = array ("From: emma.schreifels@gmail.com", "Reply-To: emma.schreifels@gmail.com", "X-Mailer: PHP/" . PHP_VERSION);
	$headers = implode("\r\n", $headers);
	
	
	
	// send email
	mail("emma.schreifels@ndsu.edu","Appointment Confirmation",$msg, $headers);
	
	
	
	
	
	
    //set query to put appointment in data base = set status to 1, insert student id etc. use update!
	$query = "UPDATE appointments SET StudentID = '".$sID."', Status = '1' WHERE Date = '".$date."'
			  AND AdvisorID ='".$aID."' AND Time ='".$time."';";
    
	$result = $conn->query($query);
    $conn->close();      
?>
<br><br><br><br><br><br><br>
</center>
</body>
</html>
<?php
include ('footer.php');?>
