


<?php include ('header.php');
// Create connection
	$conn = new mysqli('rei.cs.ndsu.nodak.edu', 'emmschre_371s17', 'DAm8GEgXO6');

	// Check connection
	//if ($conn->connect_error) {
		//die("Connection failed: " . $conn->connect_error);
	//}
	//else{
		//echo "Connected successfully";
	//}
  
  mysqli_select_db($conn, "emmschre_371s17");

  //save the advisor ID in a variable
  $aID = $_COOKIE["advisorid"];
  //$date = "2017-05-08";
  $date = $_POST["day"];
  setcookie("apptday", $date);
  
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Schedule</title>
	<link rel="stylesheet" type="text/css" href="style-sign.css">
    <link href='//fonts.googleapis.com/css?family=Bokor' rel='stylesheet'>
    <style>
        body {font-family: 'Bokor';}
		table {padding: 25px;}
		.thead {
			 text-align: center;
			 background-color: #5D6D7E;
			 color: white;
			 padding: 15px;}
		#buttonformat{
			display: inline block;
			background: #85929E;
			padding: 10px;
			text-align: center;
			border-radius: 5px;
			color: white;
			font-weight: bold;
			text-decoration: none;}
</style>
</head>
<body>
    <center><h1>Available Appointments:</h1>
    View by . . . 
    <a  class= "buttonlink" href= "http://students.cs.ndsu.nodak.edu/~emmschre/finalwebscripting/chooseday.php">Day</a>
    <a  class= "buttonlink" href= "http://students.cs.ndsu.nodak.edu/~emmschre/finalwebscripting/schedule.php">Week</a>
    <br><br><br>
    <?php
    //set query to account for status, advisor id, and date (at least for testing purposes)
        $query = "SELECT Time FROM appointments WHERE Status = 0 AND AdvisorID ='".$aID."' AND Date='".$date."';";
        $result = $conn->query($query);
		print "<table>";
		print "<tr>";
		print "<td class = 'thead'>";
        print "Date : ".$date;
		print "</td>";
		print "</tr>";
		print "<tr>";
		print "<td>";
        print "<form method='POST' action='confirmation.php'>";
        for($c=0; $row=  mysqli_fetch_row($result); $c++)
        {
             foreach($row as $key => $value)
             print "<input type='radio' name='time' value='".$value."'> $value <br>";
        }
		print "</td>";
		print "</tr>";
		print "</table>";
        print "<br><br>Reason for Appointment: <input required type = 'text' name = 'reason'>";
		print "<br><br>Description: <input required type = 'textarea' name = 'description'>";
        print "<br><br><input type = 'submit' id = 'buttonformat' name = 'submit' value = 'Schedule Appt'>";
        print "</form>";
		
        $conn->close();
        ?>
<br><br><br><br><br><br><br>
    </center>
</body>
</html>
<?php
include ('footer.php');
?>
