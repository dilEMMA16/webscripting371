<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN""http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<title>Student Portal</title>
		<link rel="stylesheet" type="text/css" href="style-sign.css">
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lobster">
		<style>
			.lobster {
				    font-family: "Lobster", serif;
				}
		</style>
		
	</script>
	</head>
	<body>
	<!-- html to be inserted into calling page -->
			<div id="header">
				
				<br>
			<h1 align="center" id="headertitle" class="lobster"><em>Student Portal</em></h1>
			<h3 align="right" id="headandfoot">Signed In: <?php echo $_COOKIE["sfirstname"]?> <?php echo $_COOKIE["slastname"]?>          </h3>
				
			<div class="topnav" id="myTopnav">
				<a href= "http://students.cs.ndsu.nodak.edu/~emmschre/finalwebscripting/welcome.php">Home</a>
				<a href= "http://students.cs.ndsu.nodak.edu/~emmschre/finalwebscripting/schedule.php">Schedule</a>
				<a href= "http://students.cs.ndsu.nodak.edu/~emmschre/finalwebscripting/change.php"">Change</a>
				<a href= "http://students.cs.ndsu.nodak.edu/~emmschre/finalwebscripting/delete.php">Delete</a>
				<a href= "http://students.cs.ndsu.nodak.edu/~emmschre/finalwebscripting/login.html">Logout</a>
			</div>	
			</div>
	