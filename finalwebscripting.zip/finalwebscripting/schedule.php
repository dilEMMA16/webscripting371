<?php include ('header.php');
// Create connection
	$conn = new mysqli('rei.cs.ndsu.nodak.edu', 'emmschre_371s17', 'DAm8GEgXO6');

	// Check connection
	/*
		   if ($conn->connect_error) {
			   die("Connection failed: " . $conn->connect_error);
		   }
		   else{
			   echo "Connected successfully";
		   }
	 */

  mysqli_select_db($conn, "emmschre_371s17");

  //save the advisor ID in a variable
  $aID = $_COOKIE["advisorid"];
  $monday = "2017-05-08";
  $tuesday = "2017-05-09";
  $wednesday = "2017-05-10";
  $thursday = "2017-05-11";
  $friday = "2017-05-12";
  
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Schedule</title>
	<link rel="stylesheet" type="text/css" href="style-sign.css">
    <link href='//fonts.googleapis.com/css?family=Bokor' rel='stylesheet'>
    <style>
        body {font-family: 'Bokor';}
		table {padding: 25px;}
		.thead{
			 text-align: center;
			 background-color: #5D6D7E;
			 color: white;
			 padding: 15px;}
		#buttonformat{
			display: inline block;
			background: #85929E;
			padding: 10px;
			text-align: center;
			border-radius: 5px;
			color: white;
			font-weight: bold;
			text-decoration: none;}
</style>
</head>
<body>
    <center><h1>Available Appointments:</h1>
    View by . . . 
    <a  class= "buttonlink" href= "http://students.cs.ndsu.nodak.edu/~emmschre/finalwebscripting/chooseday.php">Day</a>
    <a  class= "buttonlink" href= "http://students.cs.ndsu.nodak.edu/~emmschre/finalwebscripting/schedule.php">Week</a>
	
    <br><br><br>
	
    <?php
    //set query to account for status, advisor id, and day of the week
	print "<form method='POST' action='confirmationweek.php'>";
	print "<table>";
	
	print "<tr>
		   <td class = 'thead'>Monday</td>
		   <td class = 'thead'>Tuesday</td>
		   <td class = 'thead'>Wednesday</td>
		   <td class = 'thead'>Thursday</td>
		   <td class = 'thead'>Friday</td>
		   </tr>";
	print "<tr>";
		//mon
		print "<td>";
			   $query = "SELECT Time FROM appointments WHERE Status = 0 AND AdvisorID ='".$aID."' AND Date='".$monday."';";
			   $result = $conn->query($query);
						
							for($c=0; $row=  mysqli_fetch_row($result); $c++){
								 foreach($row as $key => $value)
								 $newValue1 = (string)$value."1";
								 print "<input type='radio' name='time' value='".$newValue1."'> $value <br>";}
		print "</td>";
		//tues
		print "<td>";
			   $query = "SELECT Time FROM appointments WHERE Status = 0 AND AdvisorID ='".$aID."' AND Date='".$tuesday."';";
			   $result = $conn->query($query);
							
							for($c=0; $row=  mysqli_fetch_row($result); $c++){
								 foreach($row as $key => $value)
								 $newValue2 = (string)$value."2";
								 print "<input type='radio' name='time' value='".$newValue2."'> $value <br>";}
		print "</td>";
		//wed
		print "<td>";
			   $query = "SELECT Time FROM appointments WHERE Status = 0 AND AdvisorID ='".$aID."' AND Date='".$wednesday."';";
			   $result = $conn->query($query);
							
							for($c=0; $row=  mysqli_fetch_row($result); $c++){
								 foreach($row as $key => $value)
								 $newValue3 = (string)$value."3";
								 print "<input type='radio' name='time' value='".$newValue3."'> $value <br>";}
		print "</td>";
		//thurs
		print "<td>";
			   $query = "SELECT Time FROM appointments WHERE Status = 0 AND AdvisorID ='".$aID."' AND Date='".$thursday."';";
			   $result = $conn->query($query);
				
							for($c=0; $row=  mysqli_fetch_row($result); $c++){
								 foreach($row as $key => $value)
								 $newValue4 = (string)$value."4";
								 print "<input type='radio' name='time' value='".$newValue4."'> $value <br>";}
		print "</td>";
		//fri
		print "<td>";
			   $query = "SELECT Time FROM appointments WHERE Status = 0 AND AdvisorID ='".$aID."' AND Date='".$friday."';";
			   $result = $conn->query($query);
							
							for($c=0; $row=  mysqli_fetch_row($result); $c++){
								 foreach($row as $key => $value)
								 $newValue5 = (string)$value."5";
								 print "<input type='radio' name='time' value='".$newValue5."'> $value <br>";}
		print "</td>";
	
	print "</tr>";
	
	print "</table>";					
									
	print "<br><br>Reason for Appointment: <input required type = 'text' name = 'reason'>";
	print "<br><br>Description: <input required type = 'textarea' name = 'description'>";
	print "<br><br><input type = 'submit' id = 'buttonformat' name = 'submit' value = 'Schedule Appt'>";
	print "</center>";
	print "</form><br><br><br>";
		
    $conn->close();       ?>

<br><br><br><br>
</body>
</html>
<?php
include ('footer.php');?>
