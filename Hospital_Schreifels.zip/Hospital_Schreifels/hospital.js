// JavaScript source code
function TotalCharges()
{
    var total = StayCharges() + MiscCharges();
    //output
    document.getElementById("total").innerHTML = "$" + total.toFixed(2);
}

function StayCharges() {
    var days;
    //input
    days = parseFloat(document.getElementById("days").value);
    var temp = days * 350;
    return temp;
}

function MiscCharges() {
    var medic= parseFloat(document.getElementById("medication").value);
    var charges = parseFloat(document.getElementById("charges").value);
    var fees = parseFloat(document.getElementById("fees").value);
    var physical = parseFloat(document.getElementById("physical").value);
    var temp = medic + charges + fees + physical + temp;

    return temp;
}