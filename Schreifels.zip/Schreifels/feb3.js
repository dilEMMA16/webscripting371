// JavaScript source code

function myFunction()
{
    var x = parseFloat(document.getElementById("number1").value);
    var y = parseFloat(document.getElementById("number2").value);

    //document.writeln(x + " + " + y + " = " + (x + y));
    document.getElementById("total").innerHTML = "$" + (x + y).toFixed(2);
}
