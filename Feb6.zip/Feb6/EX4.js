// JavaScript source code
function myFunction() {
    if (document.getElementById("book").selected = true)
        alert("value = " + document.getElementById("book").value);
}
