// JavaScript source code
function myFunction() {


    if (document.getElementById("number").selected = true)
        alert("value = " + document.getElementById("number").value);
}