// JavaScript source code
function myFunction() {
    var radios = document.getElementsByName('q1');
    var result = -1;
    for (var i = 0, length = radios.length; i < length; i++) {
        if (radios[i].checked) {
            // do whatever you want with the checked radio
            //alert(radios[i].value);
            result = radios[i].value;


            // only one radio can be logically checked, don't check the rest
            break;
        }
    }

    alert(result);

    //output
    document.getElementById("result").innerHTML = "Result" + result;
}
