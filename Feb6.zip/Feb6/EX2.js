// JavaScript source code
function myFunction() {
    if (document.getElementById("book").checked = true)
        alert("value = " + document.getElementById("book").value);
}
