
// JavaScript source code

window.onload = function (e) {
    var mainForm = document.getElementById("mainForm");

    var filledOut = true;

    var reqInputs = document.querySelectorAll(".required"); //array of all fields marked required

    for (var i = 0; i < reqInputs.length; i++) { //go through all required fields and make them blue on focus
        reqInputs[i].onfocus = function () {
            this.style.backgroundColor = "blue";
        }
    }


    function submitResult() {
        var reqInputs = document.querySelectorAll(".required"); //array
        

        for (var i = 0; i < reqInputs.length; i++) { //go through all required fields and check if blank, stop submit, and make the fields red instead (else submit)

            //validate HTML inputs
            if (isBlank(reqInputs[i])) //isBlank - function 
            {
                e.preventDefault(); //stop submission                                
                makeRed(reqInputs[i]); //makeRed - function
                filledOut = false;
                
            }
            else {

                makeClean(reqInputs[i]); //makeClean - function

            }
        }


    }

    //validation with isBlank
    function isBlank(inputField) {

        if (inputField.type == "checkbox") {
            if (inputField.checked)
            { return false; }
            else
            { return true; }
        }

        if (inputField.value == "" || inputField.value == null || inputField.value == "Choose continent" || inputField.value == "Choose country")
            return true;

        if (inputField.type == "description") {
            if (inputField.value == "")
            { return true; }

            else { return false; }
        }


    }


    function makeClean(inputDiv) {
        inputDiv.style.backgroundColor = "#FFFFFF";
        inputDiv.style.color = "#000000";

        var reqInputs = document.querySelectorAll(".required"); //array
        
        for (var i = 0; i < reqInputs.length; i++) {
            inputDiv.parentNode.style.backgroundColor = "white";
            inputDiv.style.border = "solid 1px black";
        }

    }

    function makeRed(inputDiv) {
        inputDiv.parentNode.style.backgroundColor = "red";
        inputDiv.style.border = "solid 5px red";

    }

    function checkSubmit()
    {
        if (filledOut) {
            submitResult();
        }

        else {

        }
    }

    document.getElementById("submit").addEventListener("click", checkSubmit);


}


