
<!DOCTYPE HTML>
<html lang="en">
<head>

<title>PHP Form Action</title>
</head>
<body>
    
   Address:
   <br>
   
   City:
   <br>
   
   State:
   
   <br>
   
   Zip:
   
   <br>
   
<?php
$result = $_POST["address"];
   echo ("Address: ".$result); 
    
$city = $_POST["city"];
   echo ("City: ".$city); 
   
$state = $_POST["state"];
   echo ("State: ".$state); 
   
$zip = $_POST["zip"];
   echo ("ZIP: ".$zip); 
    
?>

</body>
</html>



