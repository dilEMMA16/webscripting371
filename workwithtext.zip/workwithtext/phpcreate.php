<?php
$myfile = fopen("newfile.txt", "w") or die("Unable to open file!");
$txt = "CSCI160\n";
fwrite($myfile, $txt);
$txt = "CSCI161\n";
fwrite($myfile, $txt);
fclose($myfile);

?>