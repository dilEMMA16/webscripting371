<?php
$myfile = fopen("test.txt", "a") or die("Unable to open file!");
$txt = "CSCI371\n";
fwrite($myfile, $txt);
$txt = "CSCI372\n";
fwrite($myfile, $txt);
fclose($myfile); 
 
?>