		<div id="footer">  
			<h3>*Carla's Motto: Never miss a chance to teach -- and to learn!</h3>
		</div>
	</div>
</body>
</html>
