function showHint(str)
{
// if str.length = 0

//if window.XMLHttpRequest -- code for IE7+, Firefox, Chrome, Opera, Safari

// else code for IE6, IE5

//xmlhttp.onreadystatechange

// xmlhttp.open
// xmlhttp.send();
}
