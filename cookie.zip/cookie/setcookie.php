<?php

$user=$_POST['user'];
$color=$_POST['color'];
$self = $_SERVER['PHP_SELF'];

if (($user !=null) and ($color != null))
{
    setcookie("firstname", $user, time() + 36000);
    setcookie("color", $color, time() + 3600);
    header("Location: getcookie.php");
    exit();
}


?>