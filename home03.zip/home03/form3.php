<html>
     <head>
          <title>Form Three Results</title>
          <?php
               $name = $_REQUEST["name"];
               $bulbs = $_POST['bulbs'];
               $ccard = $_REQUEST["ccard"];
               
               $tax = 0;
               $orderTotal= 0;
               
               foreach ($_POST['bulbs'] as $choice) {
                    
                    if ($choice == "Four 25-watt light bulbs for $2.39")
                    {
                         $orderTotal = $orderTotal + 2.39;
                    }
                    elseif ($choice == "Eight 25-watt light bulbs for $4.29")
                    {
                         $orderTotal = $orderTotal + 4.29;
                    }
                    elseif ($choice == "Four 25-watt long-life light bulbs for $3.95")
                    {
                         $orderTotal = $orderTotal + 3.95;
                    }
                    elseif ($choice == "Eight 25-watt long-life light bulbs for $7.49")
                    {
                         $orderTotal = $orderTotal + 7.49;
                    }
                    else
                    {
                         $orderTotal = $orderTotal +0;
                    }
                    
                }
                
                $orderTotalWithTax = $orderTotal*1.062;
                $tax = $orderTotal*.062;
                
               
               ?>
     </head>
     <body>
          
          <h1>Order Summary:</h1><br>
          Name: <?php echo($name); ?> <br>
          Bulbs Ordered: <br>
          <?php
               if(!empty($_POST['bulbs'])) {
                    foreach($_POST['bulbs'] as $b) {
                         echo $b . "<br>";
                    }
               }
          ?>
          <br>
          Credit Card Used: <?php echo($ccard); ?> <br>
          Order Subtotal: <?php echo($orderTotal); ?> <br>
          Tax: <?php printf("%.2f",$tax)   ?> <br>
          Order Total (after tax): <?php printf("%.2f",$orderTotalWithTax); ?> <br>
          <h3>Thank you for your purchase!</h3>
          
          <?php
          $myFile = fopen("form3.txt", "a") or die ("Unable to open file!");
               fwrite($myFile, "Name: " . $name . "\n");
               fwrite($myFile, "Selections:\n");
               foreach ($_POST['bulbs'] as $bu)
               {
                    fwrite($myFile, $bu . "\n");
               }
               fwrite($myFile, "Subtotal: " . $orderTotal . "\n");
               fwrite($myFile, "Tax: " . $tax . "\n");
               fwrite($myFile, "Total: " . $orderTotalWithTax . "\n");
               fclose($myFile);
          
          ?>
     </body>
     
</html>

