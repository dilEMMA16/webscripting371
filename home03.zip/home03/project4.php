<html>
    <head>
        <?php

            $books = array("1984", "Brave New World", "Blindness", "Anthem", "Delirium", "The Diary of an Oxygen Thief"
                   , "The A to Z of You and Me", "Emmaus", "The Host", "City of Ember", "The Rosie Project",
                   "Island", "The Hunger Games", "Maze Runner", "Emma", "Ophelia", "The Great Gatsby", "The Giver",
                   "The Invisible Life of Ivan Isaenko", "The Fault in Our Stars", "The Time Machine");
        ?>
        <title>Project Four</title>
    </head>
    <body>
        <center>
        Hello, <?php echo ($_POST["username"]); ?>!
        </center>
        <br>
        For your favorite book, you entered <?php echo($_POST["favbook"]); ?>.
        <br><br>
        Did you mean . . . Hints display here
        <?php
            foreach ($books as $b)
            {
                $text = $_POST["favbook"];
                if (strncasecmp($b,$text,1) = 0)
                {
                    echo ($b . "<br>");
                }
            }
        
        ?>
        </center>
        
        
    
        
        
        
        
    </body>
</html>

