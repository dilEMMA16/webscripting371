<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Form Two Results</title>
</head>
<body>
    <h1>Thank You</h1>
    <p>Here is the information you have submitted:</p>
    <ol>
        <li><em>First Name: </em> <?php echo $_REQUEST["fname"]?></li>
        <li><em>Last Name:</em> <?php echo $_REQUEST["lname"]?></li>
        <li><em>Email:</em> <?php echo $_REQUEST["email"]?></li>
        <li><em>Year in College (optional):</em> <?php echo $_REQUEST["year"]?></li>
    </ol>
</body>
</html>