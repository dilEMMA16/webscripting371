<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Form One Results</title>
</head>
<body>
    <h1>Thanks</h1>
    <p>Here is the information you have submitted:</p>
    <ol>
        <li><em>Email:</em> <?php echo $_REQUEST["email"]?></li>
        <li><em>Web Usage:</em> <?php echo $_REQUEST["webUse"]?></li>
        <li><em>Occupation:</em> <?php echo $_REQUEST["occupation"]?></li>
        <li><em>Junk Mail:</em> <?php echo $_REQUEST["junkMail"]?></li>
    </ol>
</body>
</html>




