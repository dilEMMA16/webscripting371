// JavaScript source code

window.onload = function (e) {

    document.getElementById("Button1").addEventListener("click", validateInput);
    //alert("connectedd");
}

function clearForm()
{
    document.getElementById("form1").reset();
}

function radioButtons(name) {
    var radios = document.getElementsByName(name);

    for (var i = 0, length = radios.length; i < length; i++) {
        if (radios[i].checked) {
            // do whatever you want with the checked radio
            return radios[i].value;

            // only one radio can be logically checked, don't check the rest
            break;
        }
    }
}

function lists(name) {
    if (document.getElementById(name).selected = true)
        return document.getElementById(name).value;

}

function checkboxes(name) {
    var boxes = document.getElementsByName(name);
    var checkedBoxes = new Array();
    var results = "";

    for (var i = 0, length = boxes.length; i < length; i++) {
        if (boxes[i].checked) {
            // add any checked boxes to the checkedBoxes array
            checkedBoxes.push(boxes[i].value);
        }
    }

        for (var k = 0, length = checkedBoxes.length; k < length; k++)
        {
            results = results + checkedBoxes[k] + "\n";
        }

        return results;

    
}






function displayResults()
{

    var name = document.getElementById("name").value;

    var email = document.getElementById("email").value;

    var siteComments = checkboxes("site");

    var rating = lists("rate");

    var love = radioButtons("kk");

    var improve = lists("improveHow");

    var comments = document.getElementById("comments").value;


    //alert("Name: " + name + "\n\nEmail: " + email + "\n\nSite Overall: " + siteComments + "\n\nRating: " + rating + "\nLove: " + love
    //      + "\n\nImprovements: " + improve + "\n\nComments: " + comments);

    document.writeln("Name: " + name + "</br>");
    document.writeln("Email: " + email + "</br>");
    document.writeln("Site Overall: " + siteComments + "</br>");
    document.writeln("Rating: " + rating + "</br>");
    document.writeln("Love: " + love + "</br>");
    document.writeln("Improvements: " + improve + "</br>");
    document.writeln("Comments: " + comments + "</br>");
}

function validateInput()
{
    var formValid = true;
    //alert("in validateInput");

    //check that all input filled out
    var name = document.getElementById("name").value;
    if (name === "") {
        // code to run if the field is blank
        formValid = false;
    }
    //alert(formValid);

    var email = document.getElementById("email").value;
    if (email === "" ) {
        // code to run if the field is blank
        formValid = false;
    }
    //alert(formValid);

    var siteComments = checkboxes("site");
    if (siteComments === null || siteComments===undefined) {
        // code to run if the field is blank
        formValid = false;
    }
    //alert(formValid);

    var rating = lists("rate");
    if (rating === null || rating === undefined) {
        // code to run if the field is blank
        formValid = false;
    }
    //alert(formValid);

    var love = radioButtons("kk");
    if (love === null || love === undefined) {
        // code to run if the field is blank
        formValid = false;
    }
    //alert(formValid);


    var improve = lists("improveHow");
    if (improve === null || improve === undefined) {
        // code to run if the field is blank
        formValid = false;
    }
    //alert(formValid);


    var comments = document.getElementById("comments").value;
    //alert(formValid);

    //if invalid = put error message and reset form
    if (formValid == false)
    {
        alert("Please fill out the form completely");
    }


    //if valid  = displayResults()
    else
    {
        displayResults();
    }

}