// JavaScript source code
//need to read submitted info from html form and display on blank webpage

window.onload = function (e) {

    //document.getElementById("submit").addEventListener("click", results);
    document.getElementById("submit").addEventListener("click", results);


    alert("connd");

}

    function radioButtons(name) {
        var radios = document.getElementsByName(name);

        for (var i = 0, length = radios.length; i < length; i++) {
            if (radios[i].checked) {
                // do whatever you want with the checked radio
                return radios[i].value;

                // only one radio can be logically checked, don't check the rest
                break;
            }
        }
    }

    function lists(name) {
        if (document.getElementById(name).selected = true)
            return document.getElementById(name).value;

    }


    function results() {

        
        //alert("goes into results");
        //alert("does more");

        var firstName = document.getElementById("fName").value;
        //alert("fn");
        var lastName = document.getElementById("lName").value;
        //alert("ln");
        var street = document.getElementById("street").value;
        //alert("street");
        var street2 = document.getElementById("street2").value;
        //alert("street2");
        var city = document.getElementById("city").value;
        //alert("city");
        var state = lists("state"); //stops working right here in FireFox
        //alert("state");
        var zip = document.getElementById("zip").value;
        //alert("zip");
        var country = document.getElementById("country").value;
       // alert("country");
        var phone = document.getElementById("phone").value;
       // alert("phone"); 
        var ccard = radioButtons("cc");
        //alert("cc");
        var ccardnumber = document.getElementById("ccardnumber").value;
        //alert("ccnumber");
        var expirationDateMonth = lists("ccardmonth");
        //alert("ccmonth");
        var expirationDateYear = lists("ccardyear");
        //alert("ccyear");
        var csc = document.getElementById("csc").value;
       // alert("csc");
        var email = document.getElementById("contactEmail").value;
       // alert("email");
        var comments = document.getElementById("specialNotes").value;
        //alert("comments");

        //alert("past vars");
        /*alert("First Name: " + firstName + "</br>" + "Last Name: " + lastName + "</br>" + "Street Address: " + street 
            + "</br>" + "Street Address (2): " + street2 + "</br>" + "State: " + state + "</br>" + "Zip Code: " + zip + "</br>" + "Country: "
            + country + "</br>" + "Phone: " + phone + "</br>" + "Credit Card Type: " + ccard + "</br>" + "Expiration Date: " +
            expirationDateMonth + "/" + expirationDateYear + "</br>" + "CSC: " + csc + "</br>" + "Contact Email: " + email + "</br>" +
            "Special Notes: " + comments); */

            

        //alert("into");


        document.writeln("First Name: " + firstName + "</br>");
        document.writeln("Last Name: " + lastName + "</br>");
        document.writeln("Street Address:" + street + "</br>");
        document.writeln("Street Address (2): " + street2 + "</br>");
        document.writeln("State: " + state + "</br>");
        document.writeln("Zip Code: " + zip +  "</br>");
        document.writeln("Country: " + country +  "</br>");
        document.writeln("Phone: " + phone +  "</br>");
        document.writeln("Credit Card Type: " + ccard + "</br>");
        document.writeln("Expiration Date: " +
            expirationDateMonth + "/" + expirationDateYear + "</br>");
        document.writeln("CSC: " + csc +  "</br>");
        document.writeln("Contact Email: " + email +  "</br>");
        document.writeln("Special Notes: " + comments + "</br>");





    }

    /*
        function validateInput() {
            
            formValid = true;
    
            //need to check that a credit card type is selected
            var cc = radioButtons("cc");
            if (cc === null || cc === undefined) {
                // code to run if the field is blank
                formValid = false;
            }
            alert(formValid);
    
            //check that month selected
            var ccmonth = lists("ccardmonth");
            if (ccmonth == "-- Month --");
            {
                formValid = false;
            }
    
    
            //check that year is selected
            var ccyear = lists("ccardyear");
            if (ccyear == "-- Year --");
            {
                formValid = false;
            }
    
            //if invalid = do sent alert
            if (formValid == false) {
                alert("Please fill out the form completely");
                e.preventDefault(); //stop submission 
            }
    
            //else call results
            else
            {
                results();
            }
    
        }
        */








