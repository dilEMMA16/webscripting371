// JavaScript source code
function convert()
{
    //get values from html doc
    var to = document.getElementById("convertTo").value;
    var from = document.getElementById("convertFrom").value;
    var number = parseFloat(document.getElementById("number").value);

    //find out what conversion function to use

    if (from == "meters" && to == "inches") { return metersToInches(number);}
    else if (from == "inches" && to == "meters") { return inchesToMeters(number); }
    else if (from == "celsius" && to == "fahrenheit") { return celsiusToFahrenheit(number); }
    else if (from == "fahrenheit" && to == "celsius") { return fahrenheitToCelsius(number); }
    else if (from == "grams" && to == "pounds") { return gramsToPounds(number); }
    else if (from == "pounds" && to == "grams") { return poundsToGrams(number); }
    else if (from == "liters" && to == "gallons") { return litersToGallons(number); }
    else if (from == "gallons" && to == "liters") { return gallonsToLiters(number); }
    else if (from == "ounces" && to == "cups") { return ouncesToCups(number); }
    else if (from == "cups" && to == "ounces") { return cupsToOunces(number); }
    else if (from == "ounces" && to == "pounds") { return ouncesToPounds(number); }
    else if (from == "pounds" && to == "ounces") { return poundsToOunces(number); }
    else if (from == "liters" && to == "cups") { return litersToCups(number); }
    else if (from == "cups" && to == "liters") { return cupsToLiters(number); }
    else { return null;}

    

}

function result()
{
    var output = convert();
    var to = document.getElementById("convertTo").value;
    var from = document.getElementById("convertFrom").value;
    var number = document.getElementById("number").value;

    //document.getElementById("result").innerHTML = "Paragraph changed!";
    if (output == null) { alert("Invalid input. Check spelling, if units are not comparable, and/or if units are supported."); }

    else { alert("There are " + output + " " + to + " in " + number + " " + from + "."); }
    
}

//conversion functions
function metersToInches(meters)
{
    var result = meters * 39.3701;
    return result;
}

function inchesToMeters(inches)
{
    var result = inches * 0.0254;
    return result;
}

function celsiusToFahrenheit(celsius)
{
    var result = ((celsius* 9)/5) + 32;
    return result;
}

function fahrenheitToCelsius(fahrenheit)
{
    var result = ((fahrenheit - 32) / 9) * 5;
    return result;
}

function gramsToPounds(grams)
{
    var result = grams * 0.00220462;
    return result;
}

function poundsToGrams(pounds)
{
    var result = pounds * 453.592;
    return result;
}

function litersToGallons(liters)
{
    var result = liters * 0.264172;
    return result;
}

function gallonsToLiters(gallons)
{
    var result = gallons * 3.78541;
    return result;
}

function ouncesToCups (ounces)
{
    var result = ounces * 0.125;
    return result;
}

function cupsToOunces (cups)
{
    var result = cups * 8;
    return result;
}

function ouncesToPounds (ounces)
{
    var result = ounces * 0.0625;
    return result;
}

function poundsToOunces (pounds)
{
    var result = pounds * 16;
    return result;
}

function litersToCups (liters)
{
    var result = liters * 4.226575;
    return result;
}

function cupsToLiters(cups)
{
    var result = cups * 0.236588;
    return result;
}
