// JavaScript source code

window.onload = function (e) {

    alert("connectedddd");

    document.getElementById("Button1").addEventListener("click", validateInput); //add event listener to get results when submit clicked
}

    function radioButtons(name) {
        var radios = document.getElementsByName(name);

        for (var i = 0, length = radios.length; i < length; i++) {
            if (radios[i].checked) {
                // do whatever you want with the checked radio
                return radios[i].value;

                // only one radio can be logically checked, don't check the rest
                break;
            }
        }
    }


    function results() {
        
        alert("runs results");
        //check questions first
        var numberWrong = 0;


        //check question one
        var q1 = radioButtons("q1");
        var q1right;
        if (q1 == "North Dakota") {
            q1right = "Correct";
            document.getElementById("q1c").innerHTML = "Correct";
        }
        else {
            q1right = "Incorrect";
            document.getElementById("q1c").innerHTML = "Incorrect";
            numberWrong = numberWrong + 1; //increment number wrong
        }


        //check question two
        var q2 = radioButtons("q2");
        var q2right;
        if (q2 == "Devil''s Food") {
            q2right = "Correct";
            document.getElementById("q2c").innerHTML = "Correct";
        }
        else {
            q2right = "Incorrect";
            document.getElementById("q2c").innerHTML = "Incorrect";
            numberWrong = numberWrong + 1; //increment number wrong
        }



        //check question three
        var q3 = radioButtons("q3");
        var q3right;
        if (q3 == "50") {
            q3right = "Correct";
            document.getElementById("q3c").innerHTML = "Correct";
        }
        else {
            q3right = "Incorrect";
            document.getElementById("q3c").innerHTML = "Incorrect";
            numberWrong = numberWrong + 1; //increment number wrong
        }


        //check question four
        var q4 = radioButtons("q4");
        var q4right;
        if (q4 == "Trump") {
            q4right = "Correct";
            document.getElementById("q4c").innerHTML = "Correct";
        }
        else {
            q4right = "Incorrect";
            document.getElementById("q4c").innerHTML = "Incorrect";
            numberWrong = numberWrong + 1; //increment number wrong
        }


        //check question five
        var q5 = radioButtons("q5");
        var q5right;
        if (q5 == "Eminem") {
            q5right = "Correct";
            document.getElementById("q5c").innerHTML = "Correct";
        }
        else {
            q5right = "Incorrect";
            document.getElementById("q5c").innerHTML = "Incorrect";
            numberWrong = numberWrong + 1; //increment number wrong
        }





        //display info = first name, last name, email, total grade (%), and what wrong and what right
       
        var totalGradePercent = ((5-numberWrong)/5) * 100;

        var firstName = document.getElementById("firstName").value;
        var lastName = document.getElementById("lastName").value;
        var email = document.getElementById("email").value;

       // alert("First Name: " + firstName + "\nLast Name: " + lastName + "\nEmail: " + email + "\nTotal Grade: " + totalGradePercent +
        //    "%\nQ1: " + q1right + "\nQ2: " + q2right + "\nQ3: " + q3right +
        //     "\nQ4: " + q4right + "\nQ5: " + q5right);

        document.writeln("First Name: " + firstName + "</br>");
        document.writeln("Last Name: " + lastName + "</br>");
        document.writeln("Email: " + email + "</br>");
        document.writeln("Total Grade: " + totalGradePercent + "%" + "</br>");
        document.writeln("Q1: " + q1right + "</br>");
        document.writeln("Q2: " + q2right + "</br>");
        document.writeln("Q3: " + q3right + "</br>");
        document.writeln("Q4: " + q4right + "</br>");
        document.writeln("Q5: " + q5right + "</br>");



    }


    function validateInput() {
        var formValid = true;
       // alert("in validateInput");

        //check that all input filled out

        var fName = document.getElementById("firstName").value;
        if (fName == "") {
            // code to run if the field is blank
            formValid = false;
        }
        //alert(formValid);


        var lName = document.getElementById("lastName").value;
        if (lName=="") {
            // code to run if the field is blank
            formValid = false;
        }
       // alert(formValid);


        var email = document.getElementById("email").value;
        var patt = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
        var result = patt.test(email);
        if (result == false)
        {
            formValid = false;
        }
       // alert(formValid);


        var q1 = radioButtons("q1");
        if (q1 === null || q1 === undefined) {
            // code to run if the field is blank
            formValid = false;
        }
       // alert(formValid);

        var q2 = radioButtons("q2");
        if (q2 === null || q2 === undefined) {
            // code to run if the field is blank
            formValid = false;
        }
        //alert(formValid);

        var q3 = radioButtons("q3");
        if (q3 === null || q3 === undefined) {
            // code to run if the field is blank
            formValid = false;
        }
       // alert(formValid);


        var q4 = radioButtons("q4");
        if (q4 === null || q4 === undefined) {
            // code to run if the field is blank
            formValid = false;
        }
       // alert(formValid);


        var q5 = radioButtons("q5");
        if (q5 === null || q5 === undefined) {
            // code to run if the field is blank
            formValid = false;
        }
       // alert(formValid);
        
        //if invalid = put error message and reset form
        if (formValid == false) {
            alert("Please fill out the form completely");
        }


            //if valid  = displayResults()
        else {
            results();
        }

    }
















