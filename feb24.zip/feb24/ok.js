// JavaScript source code

var flag = false;


function insertPlaceHolders() {

    //form elements
    var elementsArray = document.getElementsByTagName("input");
    var x = elementsArray.length;

    //validate placeholder
    for (var i =0; i<x; i++)
        if (elementsArray[i].value == "")
        {
            document.getElementById("nameinput").value = "first and last name";
            document.getElementById("emailinput").value = "address@example.com";
            document.getElementById("phoneinput").value = "###-###-####";
        }
}


//validateRequired() fields - Part2

function validateRequired() {

    //form elements

    var countInvalid = 0;

    //validate placeholder
    var inputName = document.getElementById("nameinput").value;
    var name = /^\s*(\w{1-20})+\s+(\w{1,20}\s*)+$/;
    if (inputName === "first and last name" || inputName =="" || name.test(inputName)==false)
    {
        countInvalid++;
    }

    var inputEmail = document.getElementById("emailinput").value;
    var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if (inputEmail === "address@example.com" || inputEmail == "" || mailformat.test(inputEmail))
    {
        countInvalid++;
    }

    var inputPhone = document.getElementById("phoneinput").value;
    var phone = /^\d{3}-\d{3}-\d{4}$/;
    if (inputPhone === "###-###-####"||inputPhone =="" || phone.test(inputPhone))
    {
        countInvalid++;
    }

    if (countInvalid == 0)
    {
        flag = false;
    }
    else
    {
        flag = true;
        document.getElementById("incorrect").value = "Email and phone must be valid.";
        alert("Email and phone must be valid.");
    }


}

    








    //validate form part2
    function validateForm(evt) {
        if (evt.preventDefault)
        {
            evt.preventDefault(); //prevent form from submitting
        }
        else {
            evt.returnValue = false; //prevent form from submitting in IE8
        }

        validateRequired(); //call function to validate input data

        if (flag === true) //reset value for revalidation
        {
            alert("submit");
            document.getElementsByTagName("form")[0].submit();
        }
        else {
            alert("errrrr");
        }
    }


    //create event listeners
    function createEventListeners()
    {
        var form = document.getElementsByTagName("form")[0];

        if (form.addEventListener)
        {
            form.addEventListener("submit", validateForm, false);
        }
        else if (form.attachEvent)
        {
            form.attachEvent("onsubmit", validateForm);
        }
    }

    //run initial form configuration functions
    function setUpPage()
    {
        createEventListeners();
        insertPlaceHolders();
    }

    //run set up functions when page finishes loading
    if (window.addEventListener) {
        window.addEventListener("load", setUpPage, false)
    }
    else if (window.attachEvent)
    {
        window.attachEvent("onload", setUpPage);
    }




}