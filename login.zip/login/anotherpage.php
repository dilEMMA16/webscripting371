<?php

$auth = $_COOKIE['auth'];

header( "Cache-Control: no-cache");

if ( ! $auth == "ok")
{
    header("Location: login.php");
    exit();
}
echo("You are still logged in . . .");


?>