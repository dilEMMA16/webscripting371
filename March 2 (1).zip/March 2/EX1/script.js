
var formValidity = true;







/* add placeholder text for browsers that don't support placeholder attribute */
function generatePlaceholder() {

      var addressBox = document.getElementById("addrinput");
      addressBox.value = addressBox.placeholder;
      addressBox.style.color = "rgb(178,184,183)";
      if (addressBox.addEventListener) {
         addressBox.addEventListener("focus", zeroPlaceholder, false);
        
      } else if (addressBox.attachEvent)  {
         addressBox.attachEvent("onfocus", zeroPlaceholder);
         addressBox.attachEvent("onblur", checkPlaceholder);

   }
}

/* validate required fields */
function validateRequired() {
   var inputElements = document.querySelectorAll("#contactinfo input");
   var errorDiv = document.getElementById("errorText");
   var elementCount = inputElements.length;

   var requiredValidity = true;

   var currentElement;
   try {
      for (var i = 0; i < elementCount; i++) {
         // validate all input elements in fieldset
         currentElement = inputElements[i];
         if (currentElement.value === "") {
            currentElement.style.background = "rgb(255,233,233)";
            requiredValidity = false;
         } else {
            currentElement.style.background = "white";
         }
      }
      if (requiredValidity === false) {
         throw "Please complete all fields.";
      }
      errorDiv.style.display = "none";
      errorDiv.innerHTML = "";
   }
   catch(msg) {
      errorDiv.style.display = "block";
      errorDiv.innerHTML = msg;
      formValidity = false;
   }
}


/* validate form */
function validateForm(evt) {
   if (evt.preventDefault) {
      evt.preventDefault(); // prevent form from submitting
   } else {
      evt.returnValue = false; // prevent form from submitting in IE8
   }
   //valid flag
   formValidity = true; // reset value for revalidation
   validateRequired();


    //submit form and add data to cookies
   if (formValidity === true) {


       createCookie();

      document.getElementsByTagName("form")[0].submit();
   }
}

function addToCookie(id, value) {
    document.cookie = id + escape(value);
}
function createCookie() {
    var addressBox = document.getElementById("addrinput").value;
    var cityBox = document.getElementById("cityinput").value;
    var stateBox = document.getElementById("stateinput").value;
    var zipBox = document.getElementById("zipinput").value;
    var ssn1Box = document.getElementById("ssn1").value;
    var ssn2Box = document.getElementById("ssn2").value;
    var ssn3Box = document.getElementById("ssn3").value;

    var ssn = ssn1Box + "-" + ssn2Box + "-" + ssn3Box;
   
    addToCookie("Address= ", addressBox);
    addToCookie("City= ", cityBox);
    addToCookie("State=", stateBox);
    addToCookie("ZIP=", zipBox);
    addToCookie("SSN=", ssn);
}





/* create event listeners  */
function createEventListeners() {
   var form = document.getElementsByTagName("form")[0];
   if (form.addEventListener) {
      form.addEventListener("submit", validateForm, false);
   } else if (form.attachEvent) {
      form.attachEvent("onsubmit", validateForm);
   }
}

/* run initial form configuration functions */
function setUpPage() {
   createEventListeners();
   generatePlaceholder();
}

/* run setup functions when page finishes loading */
if (window.addEventListener) {
   window.addEventListener("load", setUpPage, false);
} else if (window.attachEvent) {
   window.attachEvent("onload", setUpPage);
}