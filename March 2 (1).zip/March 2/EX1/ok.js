window.onload=function()
{
    // determine whether there is a cookie
    var allcookies = document.cookie;
    // alert("All Cookies : " + allcookies);

    // Get all the cookies pairs in an array
    var cookiearray = allcookies.split(';');

    var result = "";

    // Now take key value pair out of this array
    for (var i = 0; i < cookiearray.length; i++) {
        name = cookiearray[i].split('=')[0];
        value = cookiearray[i].split('=')[1];
        result += (name + " is : " + value) + "<br>";
    }
    document.getElementById("result").innerHTML = result;

    
         
}
