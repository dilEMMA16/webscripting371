<?php 
	$user = $_POST['user'];
	$pass = $_POST['pass'];
	$self = $_SERVER['PHP_SELF'];

	if( ( $user != null ) and ( $pass != null ) )
	{
	    if($user=="auth" and $pass == "ok") {
            setcookie("auth", "ok");
            header("Location:loggedin.php");
            exit();
        }
        else
          print("invalid login information");
}
echo("invalid login information");

?>

