window.onload = function ()// JavaScript source code
{

    var i = 1; // counter variable
    var listItem = "";
    // function to add input to list
    function processInput() {
        if (i <= 5) {
            listItem = "item" + i;
            document.getElementById(listItem).innerHTML = document.getElementById("toolBox").value; // add entered value to list
            document.getElementById("toolBox").value = ""; // clear text box
            if (i === 5) {
                document.getElementById("resultsExpl").innerHTML = "Thanks for your suggestions.";
            }
            i++;
        }
    }

    // add event listener to Submit button
    var btn = document.getElementById("button");
    if (btn.addEventListener) {
        btn.addEventListener("click", processInput, false);
    } else if (btn.attachEvent) {
        btn.attachEvent("onclick", processInput);
    }

}

