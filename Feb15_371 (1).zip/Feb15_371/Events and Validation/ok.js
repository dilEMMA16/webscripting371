window.onload = function () {
    
    function processInput() {
        var propertyWidth = 300;
        var propertyHeight = 100;

        //new window size
        var winLeft = ((screen.width - propertyWidth) / 2);
        var winTop = ((screen.height - propertyHeight) / 2);
        var winOptions = "width=300,height=100,";
        winOptions += ",left=" + winLeft;
        winOptions += ",top=" + winTop;

        //open window
        window.open("confirm.htm", "confirm", winOptions);
    }

    // add event listener to Submit button
  
      document.getElementById("submit").addEventListener("click", processInput);
           
       
    }
