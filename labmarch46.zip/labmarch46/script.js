

var delivInfo = {};
var delivSummary = document.getElementById("deliverTo");
var orderSummary = document.getElementById("order");
var orderInfo = {};

var formValid = true;

function previewOrder() {

    validateInput();

    //alert(formValid + " updated");
    //alert("preveiw");

  
    processDeliveryInfo();
    //alert("passes delivery info");
    processOrderInfo();
   // alert("passes order info");
    document.getElementsByTagName("section")[0].style.display = "block";
   // alert("completes");


   

    
}

function processDeliveryInfo() {
   //alert("gets in delivery info");
   var prop;
   delivInfo.name = document.getElementById("nameinput").value;
   delivInfo.addr = document.getElementById("addrinput").value;
   delivInfo.city = document.getElementById("cityinput").value;
   delivInfo.email = document.getElementById("emailinput").value;
   delivInfo.phone = document.getElementById("phoneinput").value;

 
   for (prop in delivInfo) {
       delivSummary.innerHTML += "<p>" + delivInfo[prop] + "</p>";
   }
   document.getElementById("deliverTo").style.display = "block";


   //alert("hello");

    /*
   delivSummary.innerHTML += "<p>Name: " + delivInfo[name] + "</p>";
   alert("hello1");
   delivSummary.innerHTML += "<p>Address: " + delivInfo[addr] + "</p>";
   alert("hello2");
   delivSummary.innerHTML += "<p>City: " + delivInfo[city] + "</p>";
   alert("hello3");
   delivSummary.innerHTML += "<p>Email: " + delivInfo[email] + "</p>";
   alert("hello4");
   delivSummary.innerHTML += "<p>Phone: " + delivInfo[phone] + "</p>";

   alert("asdlfkasdf");

   //for (prop in delivInfo) {
     // delivSummary.innerHTML += "<p>" + delivInfo[prop] + "</p>";
   //}
   document.getElementById("deliverTo").style.display = "block";
   */
}



function processOrderInfo() {
    //alert("gets in order info");
    var prop;
    orderInfo.crust = radioButtons("crust");
    orderInfo.size = lists("size");
    orderInfo.toppings = checkboxes("toppings");
    orderInfo.instructions = document.getElementById("instructions").value;

    //orderSummary.innerHTML += "<p>Crust: " + orderInfo[crust] + "</p>";
    //orderSummary.innerHTML += "<p>Size: " + orderInfo[size] + "</p>";
    //orderSummary.innerHTML += "<p>Toppings: " + orderInfo[toppings] + "</p>";
    //orderSummary.innerHTML += "<p>Instructions: " + orderInfo[instructions] + "</p>";

    for (prop in orderInfo) {
       orderSummary.innerHTML += "<p>" + orderInfo[prop] + "</p>";
   }
    document.getElementById("order").style.display = "block";
}


function validateInput()
{
    formValid = true;

    var name = document.getElementById("nameinput").value;
    if (name == null || name == undefined || name == "")
    {
        formValid = false;
    }
    var address = document.getElementById("addrinput").value;
    if (address == null || address == undefined || address == "") {
        formValid = false;
    }
    var city = document.getElementById("cityinput").value;
    if (city == null || city == undefined || city == "") {
        formValid = false;
    }
    var email = document.getElementById("emailinput").value;
    if (email == null || email == undefined || email == "") {
        formValid = false;

    }

    var emailPattern = /\S+@\S+\.\S+/;
    var emailGood = emailPattern.test(email);
    if (!emailGood)
    {
        formValid = false;
    }


    var phone = document.getElementById("phoneinput").value;
    if (phone == null || phone == undefined || phone == "") {
        formValid = false;
    }


    var phonePattern = /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im;
    var phoneGood = phonePattern.test(phone);
    if (!phoneGood) {
        formValid = false;
    }

    var crust = radioButtons("crust");
    if (crust == null || crust == undefined || crust == "") {
        formValid = false;
    }
    var size = lists("size");
    if (size == null || size == undefined || size == "") {
        formValid = false;
    }
    
    alert("end of validate");
   // alert(formValid);

    //if (formValid == true)
    //{
      //  previewOrder();
    //}

    //else
    //{
      //  alert("Please fill out the form completely");
    //}
}


/* create event listener  */
function createEventListener() {
   var previewBtn = document.getElementById("previewBtn");
   if (previewBtn.addEventListener) {
       previewBtn.addEventListener("click", previewOrder, false);
   } else if (previewBtn.attachEvent) {
       previewBtn.attachEvent("onclick", previewOrder);
   }
}

/* create event listener when page finishes loading */
if (window.addEventListener) {
   window.addEventListener("load", createEventListener, false);
} else if (window.attachEvent) {
   window.attachEvent("onload", createEventListener);
}

function lists(name) {
    if (document.getElementById(name).selected = true)
        return document.getElementById(name).value;

}


function radioButtons(name) {
    var radios = document.getElementsByName(name);

    for (var i = 0, length = radios.length; i < length; i++) {
        if (radios[i].checked) {
            // do whatever you want with the checked radio
            return radios[i].value;

            // only one radio can be logically checked, don't check the rest
            break;
        }
    }
}




function checkboxes(name) {
    var boxes = document.getElementsByName(name);
    var checkedBoxes = new Array();
    var results = "";

    for (var i = 0, length = boxes.length; i < length; i++) {
        if (boxes[i].checked) {
            // add any checked boxes to the checkedBoxes array
            checkedBoxes.push(boxes[i].value);
        }
    }

    for (var k = 0, length = checkedBoxes.length; k < length; k++) {
        results = results + checkedBoxes[k] + "\n";
    }

    return results;


}